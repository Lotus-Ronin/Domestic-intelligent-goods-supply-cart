#include <stdio.h>
#include <stdlib.h>

#include <time.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/mman.h>

#include "GPIO.h"

// 导出 GPIO 引脚
void export_gpio(int gpio)
{
    char command[100];
    snprintf(command, sizeof(command), "echo %d > /sys/class/gpio/export", gpio);
    system(command);
}

// 设置 GPIO 引脚方向
void set_gpio_direction(int gpio, const char* direction)
{
    char command[100];
    snprintf(command, sizeof(command), "echo \"%s\" > /sys/class/gpio/gpio%d/direction", direction, gpio);
    system(command);
}

// 设置 GPIO 引脚值
void set_gpio_value(int gpio, int value)
{
    char command[100];
    snprintf(command, sizeof(command), "echo \"%d\" > /sys/class/gpio/gpio%d/value", value, gpio);
    system(command);
}

// GPIO 初始化
void gpio_init(int gpio, const char* direction, int value)
{
    export_gpio(gpio); // 导出 GPIO 引脚
    set_gpio_direction(gpio, direction); // 设置 GPIO 引脚方向
    set_gpio_value(gpio, value); // 设置 GPIO 引脚值
}

/*
int main()
{
    int gpio = 1; // 设定 GPIO 引脚编号
    const char* direction = "out"; // 设定 GPIO 引脚方向
    int value = 1; // 设定 GPIO 引脚值

    gpio_init(gpio, direction, value); // 初始化并设置 GPIO

    return 0;
}

*/
