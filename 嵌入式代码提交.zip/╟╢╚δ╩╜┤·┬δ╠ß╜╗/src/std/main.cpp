#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <termios.h>
#include <errno.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <sys/stat.h>

//#define  EXPORT		"/sys/class/gpio/export"
#define  DEV_NAME1	    "/dev/ttyS1"                            /* board uart */    //UART3---侧置摄像头
#define  DEV_NAME2	    "/dev/ttyS2"                            /* board uart */    //UART4---上下位机通信
#define  DEV_NAME3	    "/dev/ttyS3"                            /* board uart */    //UART5---前置摄像头

#define pwm0 0
#define pwm1 1

//int set_port( int fd, int nSpeed, int nBits, char nEvent, int nStop );
int pwm_export(unsigned int pwm);
int pwm_unexport(unsigned int pwm);
int pwm_enable(unsigned int pwm);
int pwm_disable(unsigned int pwm);
int pwm_config(unsigned int pwm,unsigned int period,unsigned int duty_cycle);
int pwm_polarity(int pwm,int polarity);

int set_port( int fd, int nSpeed, int nBits, char nEvent, int nStop );
int open_port( char *dir );
int Uart_Send( int fd, char *send_buf, int data_len );



/*
上下位机，通信原则：

侧置Openmv-Loongson：（使用loongson标志位，实现三种不同状态的转换）
识别绿色物块：
0---：
1.暂停、鸣笛、减速
2.暂停、鸣笛、拾取
3.暂停、鸣笛、放置（永久暂停）

前置Openmv-Loongson:

识别黑线：（使用loongson来设置标志位，实现直行和右转的切换Flag）
0---右转
1---直行

Loongson-STC
0---暂停-鸣笛
1---直线行驶
2---右转行驶



*/




int main( int argc, char *argv[] )
{

    char    read_buf1[1],read_buf2[1],read_buf3[1];
    char    write_buf1[1],write_buf2[1],write_buf3[1];
    int    i, j, h, len, nread1, nread2, nread3, r;
    int    uart_fd1,uart_fd2,uart_fd3;
    int    ret;
    char command[100];
    int a=1,b=1,c=1,d=1;
    int green=1,Flag=0;


    printf( "start \r\n" );

 //   open serial port 
    uart_fd1 = open_port(DEV_NAME1);
    if ( uart_fd1 < 0 )
    {
        perror( "open uart_fd1 failed\r\n" );
        return(-1);
    }

    uart_fd2 = open_port(DEV_NAME2);
    if ( uart_fd2 < 0 )
    {
        perror( "open uart_fd2 failed\r\n" );
        return(-1);
    }

    uart_fd3 = open_port(DEV_NAME3);
    if ( uart_fd3 < 0 )
    {
        perror( "open uart_fd3 failed\r\n" );
        return(-1);
    }

 //    set serial port 
    i = set_port( uart_fd1, 115200, 8, 'N', 1 );
    if ( i < 0 )
    {
        perror( "set_port failed\r\n" );
        return(-1);
    }
    j = set_port( uart_fd2, 115200, 8, 'N', 1 );
    if ( j < 0 )
    {
        perror( "set_port failed\r\n" );
        return(-1);
    }
    h = set_port( uart_fd3, 115200, 8, 'N', 1 );
    if ( h < 0 )
    {
        perror( "set_port failed\r\n" );
        return(-1);
    }

    pwm_export(pwm0);
	pwm_enable(pwm0);
    pwm_polarity(pwm0,0);
    pwm_export(pwm1);
	pwm_enable(pwm1);
    pwm_polarity(pwm1,0);

/*   pwm_config(pwm0,20000000,1000000);                          //1000000-1450000                    (500000-2500000)
    sleep(3);
    pwm_config(pwm1,20000000,2100000);                          //1850000-2100000
    sleep(3);
    pwm_config(pwm1,20000000,1850000);
    sleep(3);
    pwm_config(pwm0,20000000,1450000);
    sleep(3);
    pwm_config(pwm1,20000000,2100000);
    sleep(3);
    pwm_config(pwm1,20000000,1850000);
    sleep(3);
    pwm_config(pwm0,20000000,1000000);
*/
            printf("My serial try open!\r\n");
            printf("Catch green!\r\n");
            sleep(6);
            pwm_config(pwm0,20000000,1000000);                          //1000000-1450000                    (500000-2500000)
            sleep(3);
            pwm_config(pwm1,20000000,2100000);                          //1850000-2100000
            sleep(3);
            pwm_config(pwm1,20000000,1850000);
            sleep(3);
            pwm_config(pwm0,20000000,1450000);
            sleep(3);
            pwm_config(pwm1,20000000,2100000);
            sleep(3);
            write_buf2[0]='2';
            Uart_Send( uart_fd2, write_buf2, sizeof(write_buf2));
            green=2;
            sleep(9);
            
    
    while ( 1 )
    {
        usleep( 50000 );
        memset( read_buf1, 0, sizeof(read_buf1) );               //初始化为0,串口读取区初始化
        memset( read_buf2, 0, sizeof(read_buf2) );               //初始化为0,串口读取区初始化
        memset( read_buf3, 0, sizeof(read_buf3) );               //初始化为0,串口读取区初始化

        tcflush( uart_fd1, TCOFLUSH );                         //初始化发送区初始化
        tcflush( uart_fd2, TCOFLUSH );                         //初始化发送区初始化
        tcflush( uart_fd3, TCOFLUSH );                         //初始化发送区初始化

        nread1 = read( uart_fd1, read_buf1, sizeof(read_buf1) );  //返回读到的字节数
        nread2 = read( uart_fd2, read_buf2, sizeof(read_buf2) );  //返回读到的字节数
        nread3 = read( uart_fd3, read_buf3, sizeof(read_buf3) );  //返回读到的字节数

     

            
        if(read_buf3[0]=='9' && green==2){
            printf("Push green!\r\n");
            write_buf2[0]='0';
            Uart_Send( uart_fd2, write_buf2, sizeof(write_buf2));
            sleep(3);
            pwm_config(pwm1,20000000,1850000);
            sleep(3);
            pwm_config(pwm0,20000000,1000000);
}
        if(read_buf2[0]=='3' ){
            printf("Push green!\r\n");
            write_buf2[0]='0';
            Uart_Send( uart_fd2, write_buf2, sizeof(write_buf2));
            sleep(3);
            pwm_config(pwm1,20000000,1850000);
            sleep(3);
            pwm_config(pwm0,20000000,1000000);
}


/       
        if(read_buf[0]=='0'){                                   //前置摄像头识别，发送暂停---暂停3s---重新启动降速（右转）
            write_buf[0] = '0';                                      //串口发送
            Uart_Send( uart_fd2, write_buf, sizeof(write_buf) );
}
        if(read_buf[0]=='0'){                                   //前置摄像头识别，发送直行
            write_buf[0] = '0';                                      //串口发送
            Uart_Send( uart_fd2, write_buf, sizeof(write_buf) );
}
         if(read_buf[0]=='0'){                                   //侧面摄像头识别绿色货物---发送暂停---鸣笛（提示补货中）---机械臂拾取红色物块---重新启动（右转）
            write_buf[0] = '0';                                      //串口发送
            Uart_Send( uart_fd2, write_buf, sizeof(write_buf) );
}       
        if(read_buf[0]=='0'){                                   //前置摄像头识别，发送直行
            write_buf[0] = '0';                                      //串口发送
            Uart_Send( uart_fd2, write_buf, sizeof(write_buf) );
}
        if(read_buf[0]=='0'){                                   //前置摄像头识别，发送右转
            write_buf[0] = '0';                                      //串口发送
            Uart_Send( uart_fd2, write_buf, sizeof(write_buf) );
}
        if(read_buf[0]=='0'){                                   //前置摄像头识别，发送直行
            write_buf[0] = '0';                                      //串口发送
            Uart_Send( uart_fd2, write_buf, sizeof(write_buf) );
}
        if(read_buf[0]=='0'){                                   //前置摄像头识别，发送右转
            write_buf[0] = '0';                                      //串口发送
            Uart_Send( uart_fd2, write_buf, sizeof(write_buf) );
}
        if(read_buf[0]=='0'){                                   //前置摄像头识别，发送直行
            write_buf[0] = '0';                                      //串口发送
            Uart_Send( uart_fd2, write_buf, sizeof(write_buf) );
}
        if(read_buf[0]=='0'){                                   //侧置摄像头识别绿色货物，发送暂停，机械臂放货
            write_buf[0] = '0';                                      //串口发送
            Uart_Send( uart_fd2, write_buf, sizeof(write_buf) );
}

  
    }
        
}



/***********GPIO***************/

// 导出 GPIO 引脚
void export_gpio(int gpio)
{
    char command[100];
    snprintf(command, sizeof(command), "echo %d > /sys/class/gpio/export", gpio);
    system(command);
}

// 设置 GPIO 引脚方向
void set_gpio_direction(int gpio, const char* direction)
{
    char command[100];
    snprintf(command, sizeof(command), "echo \"%s\" > /sys/class/gpio/gpio%d/direction", direction, gpio);
    system(command);
}

// 设置 GPIO 引脚值
void set_gpio_value(int gpio, int value)
{
    char command[100];
    snprintf(command, sizeof(command), "echo \"%d\" > /sys/class/gpio/gpio%d/value", value, gpio);
    system(command);
}

// GPIO 初始化
void gpio_init(int gpio, const char* direction, int value)
{
    export_gpio(gpio); // 导出 GPIO 引脚
    set_gpio_direction(gpio, direction); // 设置 GPIO 引脚方向
    set_gpio_value(gpio, value); // 设置 GPIO 引脚值
}

/*************PWM************/
//打开PWM接口
int pwm_export(unsigned int pwm)
{
    int fd;
	 if(pwm == 0)
	 {fd = open("/sys/class/pwm/pwmchip0/export",O_WRONLY);}
	 else if(pwm == 1)
	 {fd = open("/sys/class/pwm/pwmchip1/export",O_WRONLY);}
	 else if(pwm == 2)
	 {fd = open("/sys/class/pwm/pwmchip2/export",O_WRONLY);}
	 else if(pwm == 3)
	 {fd = open("/sys/class/pwm/pwmchip3/export",O_WRONLY);}

    if(fd<0)
    {
        printf("\nFailed expport PWM%c\n",pwm);
        return -1;
    }
    write(fd,"0",2);
    close(fd);
    return 0;
}

//关闭PWM接口
int pwm_unexport(unsigned int pwm)
{
    int fd;
	 if(pwm == 0)
	 {fd = open("/sys/class/pwm/pwmchip0/unexport",O_WRONLY);}
	 else if(pwm == 1)
	 {fd = open("/sys/class/pwm/pwmchip1/unexport",O_WRONLY);}
	 else if(pwm == 2)
	 {fd = open("/sys/class/pwm/pwmchip2/unexport",O_WRONLY);}
	 else if(pwm == 3)
	 {fd = open("/sys/class/pwm/pwmchip3/unexport",O_WRONLY);}
    if(fd<0)
    {
        printf("\nFailed unexpport PWM%d\n",pwm);
        return -1;
    }
    write(fd,"0",2);
    close(fd);
    return 0;
}
//使能pwm
int pwm_enable(unsigned int pwm)
{
    int fd;
    if(pwm == 0)
	 {fd = open("/sys/class/pwm/pwmchip0/pwm0/enable",O_WRONLY);}
	 else if(pwm == 1)
	 {fd = open("/sys/class/pwm/pwmchip1/pwm0/enable",O_WRONLY);}
	 else if(pwm == 2)
	 {fd = open("/sys/class/pwm/pwmchip2/pwm0/enable",O_WRONLY);}
	 else if(pwm == 3)
	 {fd = open("/sys/class/pwm/pwmchip3/pwm0/enable",O_WRONLY);}
    if(fd<0)
    {
        printf("\nFailed enable PWM%d\n",pwm);
        return -1;
    }
    write(fd,"1",2);
    close(fd);
    return 0;
}
//禁止使能pwm
int pwm_disable(unsigned int pwm)
{
    int fd;
    if(pwm == 0)
	 {fd = open("/sys/class/pwm/pwmchip0/pwm0/enable",O_WRONLY);}
	 else if(pwm == 1)
	 {fd = open("/sys/class/pwm/pwmchip1/pwm0/enable",O_WRONLY);}
	 else if(pwm == 2)
	 {fd = open("/sys/class/pwm/pwmchip2/pwm0/enable",O_WRONLY);}
	 else if(pwm == 3)
	 {fd = open("/sys/class/pwm/pwmchip3/pwm0/enable",O_WRONLY);}
    if(fd<0)
    {
        printf("\nFailed disable PWM%d\n",pwm);
        return -1;
    }
    write(fd,"0",2);
    close(fd);
    return 0;
}

//设置占空比
int pwm_config(unsigned int pwm,unsigned int period,unsigned int duty_cycle)
{
    int fd,len_p,len_d;
    char buf_p[10];
    char buf_d[10];
    
    len_p = snprintf(buf_p,sizeof(buf_p),"%d",period);
    len_d = snprintf(buf_d,sizeof(buf_d),"%d",duty_cycle);
    
    if(pwm == 0)
	 {fd = open("/sys/class/pwm/pwmchip0/pwm0/period",O_WRONLY);}
	 else if(pwm == 1)
	 {fd = open("/sys/class/pwm/pwmchip1/pwm0/period",O_WRONLY);}
	 else if(pwm == 2)
	 {fd = open("/sys/class/pwm/pwmchip2/pwm0/period",O_WRONLY);}
	 else if(pwm == 3)
	 {fd = open("/sys/class/pwm/pwmchip3/pwm0/period",O_WRONLY);}
    if(fd<0)
    {
        printf("\nFailed set PWM period%d\n",pwm);
        return -1;
    }
    write(fd,buf_p,len_p);
	close(fd);

    if(pwm == 0)
	 {fd = open("/sys/class/pwm/pwmchip0/pwm0/duty_cycle",O_WRONLY);}
	 else if(pwm == 1)
	 {fd = open("/sys/class/pwm/pwmchip1/pwm0/duty_cycle",O_WRONLY);}
	 else if(pwm == 2)
	 {fd = open("/sys/class/pwm/pwmchip2/pwm0/duty_cycle",O_WRONLY);}
	 else if(pwm == 3)
	 {fd = open("/sys/class/pwm/pwmchip3/pwm0/duty_cycle",O_WRONLY);}
    if(fd<0)
    {
        printf("\nFailed set PWM duty_cycle%d\n",pwm);
        return -1;
    }
    write(fd,buf_d,len_d);
    close(fd);
    return 0;
}

//设置极性
int pwm_polarity(int pwm,int polarity)
{
    int fd;
    if(pwm == 0)
	 {fd = open("/sys/class/pwm/pwmchip0/pwm0/polarity",O_WRONLY);}
	 else if(pwm == 1)
	 {fd = open("/sys/class/pwm/pwmchip1/pwm0/polarity",O_WRONLY);}
	 else if(pwm == 2)
	 {fd = open("/sys/class/pwm/pwmchip2/pwm0/polarity",O_WRONLY);}
	 else if(pwm == 3)
	 {fd = open("/sys/class/pwm/pwmchip3/pwm0/polarity",O_WRONLY);}
    
    if(fd<0)
    {
        printf("\nFailed set PWM polarity%d\n",pwm);
        return -1;
    }
    if(polarity==1)
    {
        write(fd,"normal",6);
    }
    else if(polarity==0)
    {
        write(fd,"inversed",8);
    }
    close(fd);
    return 0;
}


/**************UART********************/
int Uart_Send( int fd, char *send_buf, int data_len )
{
	int ret;

	ret = write( fd, send_buf, data_len );

	if ( data_len == ret )
	{
		return(ret);
	} else{
		return(0);
	}
}

/*
函数 `set_port` 用于配置串行端口的参数。这个函数的参数分别代表串口通信的不同属性：
- `fd`: 文件描述符，用于指定要配置的串行端口 用open_port返回。
- `nSpeed`: 波特率，指定串行通信的速率，例如 9600、19200、115200 等。
- `nBits`: 数据位，指定每个字符包含的数据位数，通常为 7 或 8 位。
- `nEvent`: 校验位，指定是否使用奇校验('O')、偶校验('E')或不使用校验('N')。
- `nStop`: 停止位，指定每个字符后面的停止位数，通常为 1 或 2 位。
例如，如果你调用 `set_port(fd, 9600, 8, 'N', 1)`，那么你就是在配置串口以 9600 波特率、8 数据位、无校验位和 1 停止位的设置进行通信。

*/
int set_port( int fd, int nSpeed, int nBits, char nEvent, int nStop )
{
	struct termios newtio, oldtio;

	memset( &oldtio, 0, sizeof(oldtio) );
	/* save the old serial port configuration */
	if ( tcgetattr( fd, &oldtio ) != 0 )
	{
		perror( "set_port/tcgetattr" );
		return(-1);
	}

	memset( &newtio, 0, sizeof(newtio) );
	/* ignore modem control lines and enable receiver */
	newtio.c_cflag	= newtio.c_cflag |= CLOCAL | CREAD;
	newtio.c_cflag	&= ~CSIZE;
	/* set character size */
	switch ( nBits )
	{
	case 8:
		newtio.c_cflag |= CS8;
		break;
	case 7:
		newtio.c_cflag |= CS7;
		break;
	case 6:
		newtio.c_cflag |= CS6;
		break;
	case 5:
		newtio.c_cflag |= CS5;
		break;
	default:
		newtio.c_cflag |= CS8;
		break;
	}
	/* set the parity */
	switch ( nEvent )
	{
	case 'o':
	case 'O':
		newtio.c_cflag	|= PARENB;
		newtio.c_cflag	|= PARODD;
		newtio.c_iflag	|= (INPCK | ISTRIP);
		break;
	case 'e':
	case 'E':
		newtio.c_cflag	|= PARENB;
		newtio.c_cflag	&= ~PARODD;
		newtio.c_iflag	|= (INPCK | ISTRIP);
		break;
	case 'n':
	case 'N':
		newtio.c_cflag &= ~PARENB;
		break;
	default:
		newtio.c_cflag &= ~PARENB;
		break;
	}
	/* set the stop bits */
	switch ( nStop )
	{
	case 1:
		newtio.c_cflag &= ~CSTOPB;
		break;
	case 2:
		newtio.c_cflag |= CSTOPB;
		break;
	default:
		newtio.c_cflag &= ~CSTOPB;
		break;
	}
	/* set output and input baud rate */
	switch ( nSpeed )
	{
	case 0:
		cfsetospeed( &newtio, B0 );
		cfsetispeed( &newtio, B0 );
		break;
	case 50:
		cfsetospeed( &newtio, B50 );
		cfsetispeed( &newtio, B50 );
		break;
	case 75:
		cfsetospeed( &newtio, B75 );
		cfsetispeed( &newtio, B75 );
		break;
	case 110:
		cfsetospeed( &newtio, B110 );
		cfsetispeed( &newtio, B110 );
		break;
	case 134:
		cfsetospeed( &newtio, B134 );
		cfsetispeed( &newtio, B134 );
		break;
	case 150:
		cfsetospeed( &newtio, B150 );
		cfsetispeed( &newtio, B150 );
		break;
	case 200:
		cfsetospeed( &newtio, B200 );
		cfsetispeed( &newtio, B200 );
		break;
	case 300:
		cfsetospeed( &newtio, B300 );
		cfsetispeed( &newtio, B300 );
		break;
	case 600:
		cfsetospeed( &newtio, B600 );
		cfsetispeed( &newtio, B600 );
		break;
	case 1200:
		cfsetospeed( &newtio, B1200 );
		cfsetispeed( &newtio, B1200 );
		break;
	case 1800:
		cfsetospeed( &newtio, B1800 );
		cfsetispeed( &newtio, B1800 );
		break;
	case 2400:
		cfsetospeed( &newtio, B2400 );
		cfsetispeed( &newtio, B2400 );
		break;
	case 4800:
		cfsetospeed( &newtio, B4800 );
		cfsetispeed( &newtio, B4800 );
		break;
	case 9600:
		cfsetospeed( &newtio, B9600 );
		cfsetispeed( &newtio, B9600 );
		break;
	case 19200:
		cfsetospeed( &newtio, B19200 );
		cfsetispeed( &newtio, B19200 );
		break;
	case 38400:
		cfsetospeed( &newtio, B38400 );
		cfsetispeed( &newtio, B38400 );
		break;
	case 57600:
		cfsetospeed( &newtio, B57600 );
		cfsetispeed( &newtio, B57600 );
		break;
	case 115200:
		cfsetospeed( &newtio, B115200 );
		cfsetispeed( &newtio, B115200 );
		break;
	case 230400:
		cfsetospeed( &newtio, B230400 );
		cfsetispeed( &newtio, B230400 );
		break;
	default:
		cfsetospeed( &newtio, B115200 );
		cfsetispeed( &newtio, B115200 );
		break;
	}
	/* set timeout in deciseconds for non-canonical read */
	newtio.c_cc[VTIME] = 0;
	/* set minimum number of characters for non-canonical read */
	newtio.c_cc[VMIN] = 0;
	/* flushes data received but not read */
	tcflush( fd, TCIFLUSH );


	/* set the parameters associated with the terminal from
	 * the termios structure and the change occurs immediately */
	if ( (tcsetattr( fd, TCSANOW, &newtio ) ) != 0 )
	{
		perror( "set_port/tcsetattr" );
		return(-1);
	}

	return(0);
}


/**
 * @brief: open serial port
 * @Param: dir: serial device path
 */
int open_port( char *dir )
{
	int fd;
	fd = open( dir, O_RDWR );
	if ( fd < 0 )
	{
		perror( "open_port" );
	}
	return(fd);
}

