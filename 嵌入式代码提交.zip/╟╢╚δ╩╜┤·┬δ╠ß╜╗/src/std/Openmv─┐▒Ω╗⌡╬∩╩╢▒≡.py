//Openmv目标货物识别代码：
import sensor
import time
from machine import UART

sensor.reset()
sensor.set_pixformat(sensor.RGB565)
sensor.set_framesize(sensor.QVGA)
sensor.set_auto_gain(False)             
sensor.set_auto_whitebal(False)         
sensor.set_auto_exposure(False)          
sensor.skip_frames(300)

green=(48, 100, -41, -10, -128, 127)          
Interest=(90,80,130,80)                          
uart=UART(3,115200)
 
while True:
    print("Open Successfully!")
    img=sensor.snapshot()
    green_blobs=img.find_blobs([green],roi=Interest,x_stride=9,y_stride=9,area_threshold=300,pixels_threshold=300)
    if green_blobs:
        print("Find green!")
        max_green_blob=max(green_blobs,key=lambda b:b.pixels())
        img.draw_rectangle(max_green_blob.rect(),color=(255,0,0))
        img.draw_cross(max_green_blob.cx(),max_green_blob.cy())
        print(max_green_blob.cx());
        if max_green_blob.cx() > 120:
            print("Geern!")
            uart.write('9')
