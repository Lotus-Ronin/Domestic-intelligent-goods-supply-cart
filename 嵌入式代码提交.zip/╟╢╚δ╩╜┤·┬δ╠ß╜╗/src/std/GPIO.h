#ifndef __GPIO_h
#define __GPIO_h

// 导出 GPIO 引脚
void export_gpio(int gpio);

// 设置 GPIO 引脚方向
void set_gpio_direction(int gpio, const char* direction);

// 设置 GPIO 引脚值
void set_gpio_value(int gpio, int value);

// GPIO 初始化
void gpio_init(int gpio, const char* direction, int value);//GPIO引脚号，模式，高低电平


#endif

