opencv黄色双线循迹代码：
#include <opencv2/opencv.hpp>
#include <iostream>
using namespace cv;
using namespace std;
int main() {
#include "opencv2/opencv.hpp"
#include "stddef.h"
#include <iostream>
#include <opencv2/highgui.hpp>
#include <opencv2/videoio.hpp>

int main() {
  std::cout << "Hello, Loongson!" << std::endl;
  cv::Mat frame;
  cv::VideoCapture capture(003);
  if (!capture.isOpened()) {
    printf("Open fialed!\r\n");
    return 0;
  }
  while (true) {
if (frame.empty()) {
    cout << "Could not open or find the image!\n";
    return -1;
}
Mat gray;
cvtColor(frame, gray, COLOR_BGR2GRAY);
GaussianBlur(gray, gray, Size(5, 5), 0);
imshow("Original", frame);
waitKey(0);
Mat edges;
Canny(gray, edges, 50, 150);
imshow("Edges", edges);
waitKey(0);
vector<Vec2f> lines;
HoughLines(edges, lines, 1, CV_PI / 180, 100);
Mat result = frame.clone();
for (size_t i = 0; i < lines.size(); i++) {
    float rho = lines[i][0], theta = lines[i][1];
    Point pt1, pt2;
    double a = cos(theta), b = sin(theta);
    double x0 = a * rho, y0 = b * rho;
    pt1.x = cvRound(x0 + 1000 * (-b));
    pt1.y = cvRound(y0 + 1000 * (a));
    pt2.x = cvRound(x0 - 1000 * (-b));
    pt2.y = cvRound(y0 - 1000 * (a));
    line(result, pt1, pt2, Scalar(0, 0, 255), 2, LINE_AA);
}
imshow("Lines", result);
waitKey(0);
Mat turn_lines = frame.clone();
for (size_t i = 0; i < lines.size(); i++) {
    float rho = lines[i][0], theta = lines[i][1];
    double angle = theta * 180 / CV_PI;
    if (angle > 30 && angle < 60) {
        Point pt1, pt2;
        double a = cos(theta), b = sin(theta);
        double x0 = a * rho, y0 = b * rho;
        pt1.x = cvRound(x0 + 1000 * (-b));
        pt1.y = cvRound(y0 + 1000 * (a));
        pt2.x = cvRound(x0 - 1000 * (-b));
        pt2.y = cvRound(y0 - 1000 * (a));
        line(turn_lines, pt1, pt2, Scalar(0, 0, 255), 2, LINE_AA);
    }
}
imshow("Turn Lines", turn_lines);
waitKey(0);
return 0;
	}
}
