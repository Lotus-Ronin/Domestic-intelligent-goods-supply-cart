下位机控制代码：
#include "main.h"

/* 测试函数头文件*/ 
#include "test_adc.h"
#include "test_enc.h"
#include "test_exti.h"
#include "test_timer.h"
#include "test_uart.h"
#include "test_eeprom.h"
#include "test_mpu6050.h"
#include "test_icm20602.h"
#include "test_9ax.h"
#include "test_ano_dt.h"
#include "test_key.h"
#include "test_led.h"
#include "test_oled.h"
#include "test_pwm.h"
#include "test_ccd.h"
#include "test_lsm6dsr.h"



#define Servo_Delta 120            													
#define Servo_Left_Max   (Servo_Center_Mid+Servo_Delta)      
#define Servo_Right_Min  (Servo_Center_Mid-Servo_Delta)      

short Motor_Bias_R, Motor_Last_Bias_R, Motor_LL_Bias_R;			 
short Motor_Bias_L, Motor_Last_Bias_L, Motor_LL_Bias_L;
short leftP=0,leftV=0,rightV=0,rightP=0;  								
short Error_P=0,Error_V=0;
int MotorDuty1=0; 	
int MotorDuty2=0;		
int xdata ECPULSE1 = 0;         	
int xdata ECPULSE2 = 0;          		
int ensum1=0;
int ensum2=0;
static int  q = 1;

int xdata Mode=1;										
char xdata ch='0';										
char xdata crl='0';									

int xdata m=1;
int i = 300;
int RAllPulse1=0;
int RAllPulse2=0;

float DJ_KP1=0.8,DJ_KD1=14,DJ_KI1=0.00000534,DJ_V1 =0.25;
//float DJ_KP1=0.8,DJ_KD1=14,DJ_KI1=0.00000534,DJ_V1 =0.23;
float DJ_KD3=22;
short ServoDuty=0,Last_ServoDuty=0;	
short Err_speed = 0;				
short S_curve=0,Straight=0,Stop=0; 
short devi_fig=0;	
short time = 0;	


short key_flag= 0;	
short xiao_da = 1;
short motor_flag = 1;
short jiemian = 0;

short DJ_KP5=2,DJ_KD5=0.0;
short DJ_KP6=1,DJ_KD6=0.0;
short DJ_KP7=1.5,DJ_KD7=0.0;
short Round=0,Round_In=0,Rounding=0,Round_Out=0,Round_Oflag=0;
short Gan;
short Gan_1=0;
int Gan_2=130;
short Gar_Out=0,Gar_In=0;
void InductorNormal (void);
void Discern(void);
void steering_control(void);
void OLED_show(void);
void MotorCtrl (int16_t duty1,int16_t duty2);
void Key_Scan(void);
int SBB_Get_MotorPI_L (int Encoder,int Target);
int SBB_Get_MotorPI_R (int Encoder,int Target);
int Get_MotorPI_L (int Encoder,int Target);
int Get_MotorPI_R (int Encoder,int Target);
void Enco();	
void Test_ENC();
void delayms(uint32_t ms);



void main(){
	char txt[36] = {0};
	char txt1[36] = {0};
	RSTCFG = 0x50; 				 
	EA =1;                
	TIMER3_Init(5000);		
	PWM_Init(0, 7, 50, Servo_Center_Mid); 
	
	LED_Init();  												
											
	OLED_Init();                         
  delayms(500);  											
  OLED_CLS();  													
	
	PWM_Init(0, 0, 12500, 0);  
	PWM_Init(1, 1, 12500, 0);  
	PWM_Init(1, 2, 12500, 0);  
	PWM_Init(1, 3, 12500, 0);  
	
	PWM_Init(0, 7, 50, Servo_Center_Mid);  
	
	TIMER3_EncInit();       
	TIMER4_EncInit();     
	
	PIN_InitStandard(0, 5);
	PIN_InitStandard(4, 7);	
	
	//PIN_InitPushPull(1, 6);
	
	UART3_InitTimer3P50P51(115200);
	
	//TIMER1_Init(5000);	
	
	PIN_InitStandard(ENC1_DIR_PORT, ENC1_DIR_INDEX);	
	PIN_InitStandard(ENC2_DIR_PORT, ENC2_DIR_INDEX); 
	
	LED_Color(violet);
	PWM_SetDuty(0, 0, 0);								
	PWM_SetDuty(1, 1, 0);							
	PWM_SetDuty(1, 2, 0);								
	PWM_SetDuty(1, 3, 0);								
	PWM_SetDuty(0, 7, Servo_Center_Mid);
	delayms(6000);
	
	while(1){
		
		sprintf(txt, "Mode: %5d", Mode);   
		OLED_P6x8Str(0, 3, txt); 	
		UART3_GetChar(ch);
			
		switch(ch){
			case '1':Mode=1;break;
				
			case '2':Mode=2;break;
						
			case '3':Mode=3;break;
			
			case '4':Mode=4;break;

			case '5':Mode=5;break;
			
			case '0':Mode=0;break;
			

		}		
		
		sprintf(txt, "ch: %5c", ch);   
		OLED_P6x8Str(0, 2, txt); 
		sprintf(txt, "Mode: %5d", Mode);   
		OLED_P6x8Str(0, 3, txt); 					

		switch(Mode){
		
			case 0:
				//暂停模式：
				LED_Color(violet);
				PWM_SetDuty(0, 0, 0);								
				PWM_SetDuty(1, 1, 0);								
				PWM_SetDuty(1, 2, 0);								
				PWM_SetDuty(1, 3, 0);							
				PWM_SetDuty(0, 7, Servo_Center_Mid);
			  PIN_InitPushPull(1, 6); 						
				delayms(3000);											
				PIN_InitPureInput(1,6);						
				Mode=1;
			break;
			
			case 1:
				//直行模式：
				LED_Color(blue);
				PWM_SetDuty(0, 0, 0);						
				PWM_SetDuty(1, 1, 1630);						
				PWM_SetDuty(1, 2, 0);							
				PWM_SetDuty(1, 3, 1630);						
				PWM_SetDuty(0, 7, Servo_Center_Mid);
			break;
			
			case 2:
				//转弯模式（右转）
				LED_Color(yellow);
				PWM_SetDuty(0, 0, 0);							
				PWM_SetDuty(1, 1, 1590);							
				PWM_SetDuty(1, 2, 0);								
				PWM_SetDuty(1, 3, 1590);							
				PWM_SetDuty(0, 7, Servo_Center_Mid+13);
				delayms(6000);
				PWM_SetDuty(0, 0, 0);							
				PWM_SetDuty(1, 1, 1690);							
				PWM_SetDuty(1, 2, 0);								
				PWM_SetDuty(1, 3, 1690);							
				PWM_SetDuty(0, 7, Servo_Center_Mid-73);		
///			Test_ENC();													
				delayms(1600);
				PWM_SetDuty(0, 7, Servo_Center_Mid);
				Mode=1;
			break;
			
			case 3:
				//暂停模式							
				LED_Color(violet);								
				PWM_SetDuty(0, 0, 0);							
				PWM_SetDuty(1, 1, 1630);								
				PWM_SetDuty(1, 2, 0);								
				PWM_SetDuty(1, 3, 1630);								
				PWM_SetDuty(0, 7, Servo_Center_Mid);													
				delayms(1300);											
				PIN_InitPushPull(1, 6); 						
			break;
			
			case 4:
				//减速鸣笛模式
				LED_Color(white);										
				PWM_SetDuty(0, 0, 0);							
				PWM_SetDuty(1, 1, 0);								
				PWM_SetDuty(1, 2, 0);								
				PWM_SetDuty(1, 3, 0);								
				PWM_SetDuty(0, 7, Servo_Center_Mid);
				PIN_InitPushPull(1, 6); 						
			break;
			
			case 5:
				LED_Color(black);
				PIN_InitPureInput(1,6);			
				PWM_SetDuty(0, 0, 0);							
				PWM_SetDuty(1, 1, 1700);							
				PWM_SetDuty(1, 2, 0);								
				PWM_SetDuty(1, 3, 1700);								
				PWM_SetDuty(0, 7, Servo_Center_Mid);
			break;
		}
	
	}
}

void delayms(uint32_t ms)  //延时函数
{
	while(ms--)
	{
		uint16_t xdata i = 300;
		while(i--)
		{
			NOP(50);
		}
	}
}	
