#include "opencv2/opencv.hpp"
#include "stddef.h"
#include <iostream>
#include <opencv2/highgui.hpp>
#include <opencv2/videoio.hpp>

int main() {
  std::cout << "Hello, Loongson!" << std::endl;
  cv::Mat frame;
  cv::VideoCapture capture(003);
  if (!capture.isOpened()) {
    printf("Open fialed!\r\n");
    return 0;
  }
  while (true) {
    capture.read(frame);
    cv::imshow("window", frame);
    cv::waitKeyEx(1);
  }
  return 0;
}
