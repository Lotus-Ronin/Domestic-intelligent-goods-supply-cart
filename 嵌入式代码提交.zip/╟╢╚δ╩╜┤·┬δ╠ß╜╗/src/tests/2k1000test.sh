#! /bin/bash
echo "开始接口测试："
echo "loongson" | sudo -S /media/loongson/2k1000la_edu.sh

#echo "loongson" | sudo -S /home/loongson/2k1000la_edu.sh
